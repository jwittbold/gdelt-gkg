import toml
import os


GDELT_HOME = os.environ.get('GDELT_HOME')

# load configuration variables from .toml file
with open(f'{GDELT_HOME}/config/config.toml', 'r') as f:
    config = toml.load(f)